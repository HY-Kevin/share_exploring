
//------------------------------------------------------------------------------
// (c) Copyright 2014 Xilinx, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//------------------------------------------------------------------------------ 
//
// C Model configuration for the "fir_compiler_0" instance.
//
//------------------------------------------------------------------------------
//
// coefficients: -25,1,1,2,2,2,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,5,5,4,4,4,4,3,3,2,2,1,1,0,0,-1,-2,-2,-3,-4,-4,-5,-6,-7,-7,-8,-8,-9,-10,-10,-11,-11,-11,-12,-12,-12,-12,-12,-12,-12,-12,-11,-11,-10,-10,-9,-8,-7,-6,-5,-4,-3,-2,0,1,2,4,5,7,8,10,11,13,14,16,17,18,19,20,21,22,23,24,24,24,25,25,25,24,24,23,22,21,20,19,17,16,14,12,10,8,5,3,0,-2,-5,-8,-11,-13,-16,-19,-22,-24,-27,-29,-32,-34,-36,-38,-40,-41,-43,-44,-45,-45,-45,-45,-45,-44,-43,-42,-41,-39,-37,-34,-31,-28,-25,-21,-18,-14,-9,-5,0,4,9,14,19,24,28,33,38,43,47,51,56,59,63,66,69,72,74,75,77,78,78,78,77,76,74,72,69,66,62,58,53,48,42,36,30,23,16,8,1,-7,-15,-23,-32,-40,-48,-56,-64,-72,-79,-86,-93,-99,-105,-111,-115,-119,-123,-126,-128,-129,-130,-129,-128,-126,-123,-119,-115,-109,-103,-96,-88,-79,-70,-60,-49,-38,-26,-14,-1,12,26,39,53,67,80,94,107,120,133,145,156,167,177,186,194,201,207,212,216,218,219,219,217,214,209,203,196,187,176,164,151,136,120,103,85,65,45,23,1,-22,-46,-70,-94,-119,-144,-168,-192,-216,-240,-262,-284,-304,-324,-342,-358,-373,-386,-397,-406,-413,-417,-418,-418,-414,-407,-398,-386,-371,-352,-331,-306,-279,-248,-214,-177,-137,-95,-49,-1,50,104,159,217,278,340,403,469,535,603,672,741,811,881,951,1021,1090,1159,1227,1293,1358,1421,1482,1541,1598,1652,1704,1752,1797,1839,1878,1913,1944,1971,1994,2013,2028,2038,2045,2047,2045,2038,2028,2013,1994,1971,1944,1913,1878,1839,1797,1752,1704,1652,1598,1541,1482,1421,1358,1293,1227,1159,1090,1021,951,881,811,741,672,603,535,469,403,340,278,217,159,104,50,-1,-49,-95,-137,-177,-214,-248,-279,-306,-331,-352,-371,-386,-398,-407,-414,-418,-418,-417,-413,-406,-397,-386,-373,-358,-342,-324,-304,-284,-262,-240,-216,-192,-168,-144,-119,-94,-70,-46,-22,1,23,45,65,85,103,120,136,151,164,176,187,196,203,209,214,217,219,219,218,216,212,207,201,194,186,177,167,156,145,133,120,107,94,80,67,53,39,26,12,-1,-14,-26,-38,-49,-60,-70,-79,-88,-96,-103,-109,-115,-119,-123,-126,-128,-129,-130,-129,-128,-126,-123,-119,-115,-111,-105,-99,-93,-86,-79,-72,-64,-56,-48,-40,-32,-23,-15,-7,1,8,16,23,30,36,42,48,53,58,62,66,69,72,74,76,77,78,78,78,77,75,74,72,69,66,63,59,56,51,47,43,38,33,28,24,19,14,9,4,0,-5,-9,-14,-18,-21,-25,-28,-31,-34,-37,-39,-41,-42,-43,-44,-45,-45,-45,-45,-45,-44,-43,-41,-40,-38,-36,-34,-32,-29,-27,-24,-22,-19,-16,-13,-11,-8,-5,-2,0,3,5,8,10,12,14,16,17,19,20,21,22,23,24,24,25,25,25,24,24,24,23,22,21,20,19,18,17,16,14,13,11,10,8,7,5,4,2,1,0,-2,-3,-4,-5,-6,-7,-8,-9,-10,-10,-11,-11,-12,-12,-12,-12,-12,-12,-12,-12,-11,-11,-11,-10,-10,-9,-8,-8,-7,-7,-6,-5,-4,-4,-3,-2,-2,-1,0,0,1,1,2,2,3,3,4,4,4,4,5,5,5,5,5,5,5,5,5,5,5,5,4,4,4,4,4,3,3,3,3,3,2,2,2,2,2,2,2,2,1,1,-25
// chanpats: 173
// name: fir_compiler_0
// filter_type: 0
// rate_change: 0
// interp_rate: 1
// decim_rate: 1
// zero_pack_factor: 1
// coeff_padding: 0
// num_coeffs: 727
// coeff_sets: 1
// reloadable: 0
// is_halfband: 0
// quantization: 0
// coeff_width: 12
// coeff_fract_width: 0
// chan_seq: 0
// num_channels: 1
// num_paths: 1
// data_width: 13
// data_fract_width: 0
// output_rounding_mode: 0
// output_width: 31
// output_fract_width: 0
// config_method: 0

const double fir_compiler_0_coefficients[727] = {-25,1,1,2,2,2,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5,5,5,4,4,4,4,3,3,2,2,1,1,0,0,-1,-2,-2,-3,-4,-4,-5,-6,-7,-7,-8,-8,-9,-10,-10,-11,-11,-11,-12,-12,-12,-12,-12,-12,-12,-12,-11,-11,-10,-10,-9,-8,-7,-6,-5,-4,-3,-2,0,1,2,4,5,7,8,10,11,13,14,16,17,18,19,20,21,22,23,24,24,24,25,25,25,24,24,23,22,21,20,19,17,16,14,12,10,8,5,3,0,-2,-5,-8,-11,-13,-16,-19,-22,-24,-27,-29,-32,-34,-36,-38,-40,-41,-43,-44,-45,-45,-45,-45,-45,-44,-43,-42,-41,-39,-37,-34,-31,-28,-25,-21,-18,-14,-9,-5,0,4,9,14,19,24,28,33,38,43,47,51,56,59,63,66,69,72,74,75,77,78,78,78,77,76,74,72,69,66,62,58,53,48,42,36,30,23,16,8,1,-7,-15,-23,-32,-40,-48,-56,-64,-72,-79,-86,-93,-99,-105,-111,-115,-119,-123,-126,-128,-129,-130,-129,-128,-126,-123,-119,-115,-109,-103,-96,-88,-79,-70,-60,-49,-38,-26,-14,-1,12,26,39,53,67,80,94,107,120,133,145,156,167,177,186,194,201,207,212,216,218,219,219,217,214,209,203,196,187,176,164,151,136,120,103,85,65,45,23,1,-22,-46,-70,-94,-119,-144,-168,-192,-216,-240,-262,-284,-304,-324,-342,-358,-373,-386,-397,-406,-413,-417,-418,-418,-414,-407,-398,-386,-371,-352,-331,-306,-279,-248,-214,-177,-137,-95,-49,-1,50,104,159,217,278,340,403,469,535,603,672,741,811,881,951,1021,1090,1159,1227,1293,1358,1421,1482,1541,1598,1652,1704,1752,1797,1839,1878,1913,1944,1971,1994,2013,2028,2038,2045,2047,2045,2038,2028,2013,1994,1971,1944,1913,1878,1839,1797,1752,1704,1652,1598,1541,1482,1421,1358,1293,1227,1159,1090,1021,951,881,811,741,672,603,535,469,403,340,278,217,159,104,50,-1,-49,-95,-137,-177,-214,-248,-279,-306,-331,-352,-371,-386,-398,-407,-414,-418,-418,-417,-413,-406,-397,-386,-373,-358,-342,-324,-304,-284,-262,-240,-216,-192,-168,-144,-119,-94,-70,-46,-22,1,23,45,65,85,103,120,136,151,164,176,187,196,203,209,214,217,219,219,218,216,212,207,201,194,186,177,167,156,145,133,120,107,94,80,67,53,39,26,12,-1,-14,-26,-38,-49,-60,-70,-79,-88,-96,-103,-109,-115,-119,-123,-126,-128,-129,-130,-129,-128,-126,-123,-119,-115,-111,-105,-99,-93,-86,-79,-72,-64,-56,-48,-40,-32,-23,-15,-7,1,8,16,23,30,36,42,48,53,58,62,66,69,72,74,76,77,78,78,78,77,75,74,72,69,66,63,59,56,51,47,43,38,33,28,24,19,14,9,4,0,-5,-9,-14,-18,-21,-25,-28,-31,-34,-37,-39,-41,-42,-43,-44,-45,-45,-45,-45,-45,-44,-43,-41,-40,-38,-36,-34,-32,-29,-27,-24,-22,-19,-16,-13,-11,-8,-5,-2,0,3,5,8,10,12,14,16,17,19,20,21,22,23,24,24,25,25,25,24,24,24,23,22,21,20,19,18,17,16,14,13,11,10,8,7,5,4,2,1,0,-2,-3,-4,-5,-6,-7,-8,-9,-10,-10,-11,-11,-12,-12,-12,-12,-12,-12,-12,-12,-11,-11,-11,-10,-10,-9,-8,-8,-7,-7,-6,-5,-4,-4,-3,-2,-2,-1,0,0,1,1,2,2,3,3,4,4,4,4,5,5,5,5,5,5,5,5,5,5,5,5,4,4,4,4,4,3,3,3,3,3,2,2,2,2,2,2,2,2,1,1,-25};

const xip_fir_v7_2_pattern fir_compiler_0_chanpats[1] = {P_BASIC};

static xip_fir_v7_2_config gen_fir_compiler_0_config() {
  xip_fir_v7_2_config config;
  config.name                = "fir_compiler_0";
  config.filter_type         = 0;
  config.rate_change         = XIP_FIR_INTEGER_RATE;
  config.interp_rate         = 1;
  config.decim_rate          = 1;
  config.zero_pack_factor    = 1;
  config.coeff               = &fir_compiler_0_coefficients[0];
  config.coeff_padding       = 0;
  config.num_coeffs          = 727;
  config.coeff_sets          = 1;
  config.reloadable          = 0;
  config.is_halfband         = 0;
  config.quantization        = XIP_FIR_INTEGER_COEFF;
  config.coeff_width         = 12;
  config.coeff_fract_width   = 0;
  config.chan_seq            = XIP_FIR_BASIC_CHAN_SEQ;
  config.num_channels        = 1;
  config.init_pattern        = fir_compiler_0_chanpats[0];
  config.num_paths           = 1;
  config.data_width          = 13;
  config.data_fract_width    = 0;
  config.output_rounding_mode= XIP_FIR_FULL_PRECISION;
  config.output_width        = 31;
  config.output_fract_width  = 0,
  config.config_method       = XIP_FIR_CONFIG_SINGLE;
  return config;
}

const xip_fir_v7_2_config fir_compiler_0_config = gen_fir_compiler_0_config();

